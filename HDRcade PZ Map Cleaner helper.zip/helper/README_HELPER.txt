HDRcade PZ B42 Map Cleaner — Python Helper (Save Index Generator)
===============================================================

What it does
------------
Generates a Save Index JSON for the web tool so it can load instantly, even for
very large servers (hundreds of thousands of .bin files).

It does NOT delete anything.

Where to point it
-----------------
Pick your SAVE ROOT folder: it must contain a 'map/' folder, and usually 'players.db'.

Examples:
  Windows (hosted server):
    C:\Users\<you>\Zomboid\Saves\Multiplayer\<servername>

  Linux (dedicated server):
    /home/<you>/Zomboid/Saves/Multiplayer/<servername>

Run it
------
Windows:
  1) Double-click: run_helper_windows.bat
  2) Paste your save root path when asked
  3) It will create: save_index.json (next to the script)

Linux:
  1) chmod +x run_helper_linux.sh
  2) ./run_helper_linux.sh
  3) It will create: save_index.json (next to the script)

Manual (any OS):
  python hdrcade_pz_b42_save_indexer.py --save-root "<path>" --out save_index.json

Load it in the web tool
-----------------------
In index.html:
  Index / Fast Mode  ->  "Load Save Index (.json)"  -> select save_index.json

Safehouses
----------
Safehouse parsing is best-effort. The helper will try to find safehouse rectangles in players.db (SQLite)
by scanning tables/columns. If your server uses a different schema, safehouses may show as 0.

