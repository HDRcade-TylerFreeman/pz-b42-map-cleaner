HDRcade Save Index Helper

Purpose
- Builds helper/save_index.json for fast loading in the HDRcade web tool.

How
Windows:
- Double-click helper\run_helper_windows.bat

Linux:
- chmod +x helper/run_helper_linux.sh
- ./helper/run_helper_linux.sh

Input
- SAVE ROOT path (must contain map/ and usually players.db)

Output
- helper/save_index.json

Safehouse overlay
- Best effort: scans sqlite .db files in the save root (players.db etc.)
- If safehouses aren't found, the web tool still works without overlays.
