#!/usr/bin/env bash
set -euo pipefail
echo "HDRcade PZ B42 Map Cleaner - Save Index Helper"
echo "------------------------------------------------"
echo "This creates save_index.json for fast loading in the web tool."
echo "It does NOT delete anything."
echo
read -r -p "Paste SAVE ROOT path (contains map/) then press ENTER: " SAVEROOT
if [ -z "${SAVEROOT}" ]; then
  echo "ERROR: No path provided."
  exit 1
fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "${SCRIPT_DIR}/hdrcade_pz_b42_save_indexer.py" "${SAVEROOT}"
echo
echo "DONE: ${SAVEROOT}/save_index.json"
echo "Now load it in the web tool: 1) Fast Mode > Load save_index.json"
