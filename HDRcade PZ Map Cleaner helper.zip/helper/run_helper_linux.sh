\
#!/usr/bin/env bash
set -euo pipefail

# HDRcade PZ B42 Map Cleaner - Save Index Helper (Linux)
# Creates helper/save_index.json for fast loading in the web tool.
# Does NOT delete anything.

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo
echo "HDRcade PZ B42 Map Cleaner - Save Index Helper"
echo "------------------------------------------------"
echo "This creates save_index.json for fast loading in the web tool."
echo "It does NOT delete anything."
echo

read -r -p "Paste SAVE ROOT path (contains map/) then press ENTER: " SAVEROOT
SAVEROOT="${SAVEROOT%\"}"
SAVEROOT="${SAVEROOT#\"}"

if [ ! -d "$SAVEROOT/map" ]; then
  echo
  echo "ERROR: That path does not contain map/"
  echo "You entered: $SAVEROOT"
  echo "Tip: SAVE ROOT is the folder that contains map/ and players.db"
  echo
  exit 1
fi

command -v python3 >/dev/null 2>&1 || { echo "ERROR: python3 not found"; exit 1; }

echo
echo "Running..."
python3 "$HERE/hdrcade_pz_b42_save_indexer.py" --save-root "$SAVEROOT" --out "$HERE/save_index.json" --pretty

echo
echo "DONE: $HERE/save_index.json"
echo "Now load it in the web tool: Index / Fast Mode > Load Save Index (.json)"
echo
