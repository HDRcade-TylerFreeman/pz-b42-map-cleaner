\
#!/usr/bin/env bash
set -euo pipefail

echo ""
echo "HDRcade PZ B42 Map Cleaner - Save Index Helper"
echo "------------------------------------------------"
echo "This creates save_index.json for fast loading in the web tool."
echo "It does NOT delete anything."
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT="$SCRIPT_DIR/hdrcade_pz_b42_save_indexer.py"
OUTFILE="$SCRIPT_DIR/save_index.json"

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 not found. Install Python 3 and re-run."
  exit 1
fi

read -r -p "Paste SAVE ROOT path (contains map/) then press ENTER: " SAVEROOT
if [[ -z "${SAVEROOT}" ]]; then
  echo "No path provided."
  exit 1
fi

echo ""
echo "Running..."
python3 "$SCRIPT" --save-root "$SAVEROOT" --out "$OUTFILE"

echo ""
echo "DONE: $OUTFILE"
echo "Now open the web tool and load this file via: Index / Fast Mode -> Load Save Index (.json)"
echo ""
read -r -p "Press ENTER to close..."
