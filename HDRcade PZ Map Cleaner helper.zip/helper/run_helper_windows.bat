\
@echo off
setlocal EnableExtensions EnableDelayedExpansion
title HDRcade PZ B42 Map Cleaner - Save Index Helper

echo.
echo HDRcade PZ B42 Map Cleaner - Save Index Helper
echo ------------------------------------------------
echo This creates save_index.json for fast loading in the web tool.
echo It does NOT delete anything.
echo.

where python >nul 2>nul
if errorlevel 1 (
  where py >nul 2>nul
  if errorlevel 1 (
    echo ERROR: Python not found.
    echo Install Python 3 from https://www.python.org/downloads/ and re-run.
    echo.
    pause
    exit /b 1
  )
)

set /p SAVEROOT=Paste SAVE ROOT path (contains map\) then press ENTER: 
if "%SAVEROOT%"=="" (
  echo No path provided.
  pause
  exit /b 1
)

set OUTFILE=save_index.json

echo.
echo Running...
if exist "%~dp0hdrcade_pz_b42_save_indexer.py" (
  set SCRIPT="%~dp0hdrcade_pz_b42_save_indexer.py"
) else (
  echo ERROR: Missing hdrcade_pz_b42_save_indexer.py
  pause
  exit /b 1
)

python %SCRIPT% --save-root "%SAVEROOT%" --out "%~dp0%OUTFILE%"
if errorlevel 1 (
  echo.
  echo FAILED. See errors above.
  pause
  exit /b 1
)

echo.
echo DONE: %~dp0%OUTFILE%
echo Now open the web tool and load this file via: Index / Fast Mode -> Load Save Index (.json)
echo.
pause
