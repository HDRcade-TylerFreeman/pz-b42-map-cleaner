\
@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM HDRcade PZ B42 Map Cleaner - Save Index Helper (Windows)
REM Creates helper\save_index.json for fast loading in the web tool.
REM Does NOT delete anything.

pushd "%~dp0."

echo.
echo HDRcade PZ B42 Map Cleaner - Save Index Helper
echo ------------------------------------------------
echo This creates save_index.json for fast loading in the web tool.
echo It does NOT delete anything.
echo.

set "PY="
where py >nul 2>&1 && set "PY=py -3"
if "%PY%"=="" (
  where python >nul 2>&1 && set "PY=python"
)

if "%PY%"=="" (
  echo ERROR: Python not found. Install Python 3 or ensure it is in PATH.
  echo.
  pause
  popd
  exit /b 1
)

set /p "SAVEROOT=Paste SAVE ROOT path (contains map\) then press ENTER: "
set "SAVEROOT=%SAVEROOT:"=%"

if not exist "%SAVEROOT%\map\" (
  echo.
  echo ERROR: That path does not contain map\
  echo You entered: "%SAVEROOT%"
  echo Tip: SAVE ROOT is the folder that contains map\ and players.db
  echo.
  pause
  popd
  exit /b 1
)

echo.
echo Running...
%PY% "%~dp0hdrcade_pz_b42_save_indexer.py" --save-root "%SAVEROOT%" --out "%~dp0save_index.json" --pretty
if errorlevel 1 (
  echo.
  echo FAILED. See errors above.
  pause
  popd
  exit /b 1
)

echo.
echo DONE: %~dp0save_index.json
echo Now load it in the web tool: Index / Fast Mode ^> Load Save Index (.json)
echo.
pause
popd
