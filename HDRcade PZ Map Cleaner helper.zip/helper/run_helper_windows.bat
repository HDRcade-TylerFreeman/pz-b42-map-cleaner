@echo off
setlocal EnableExtensions EnableDelayedExpansion
echo HDRcade PZ B42 Map Cleaner - Save Index Helper
echo ------------------------------------------------
echo This creates save_index.json for fast loading in the web tool.
echo It does NOT delete anything.
echo.
set /p SAVEROOT=Paste SAVE ROOT path (contains map\) then press ENTER: 
if "%SAVEROOT%"=="" (
  echo ERROR: No path provided.
  pause
  exit /b 1
)
set SCRIPT=%~dp0hdrcade_pz_b42_save_indexer.py
echo.
echo Running...
echo.

where py >nul 2>nul
if %ERRORLEVEL%==0 (
  py -3 "%SCRIPT%" "%SAVEROOT%"
) else (
  where python >nul 2>nul
  if %ERRORLEVEL%==0 (
    python "%SCRIPT%" "%SAVEROOT%"
  ) else (
    echo ERROR: Python not found. Install Python 3 and try again.
    pause
    exit /b 1
  )
)

if %ERRORLEVEL% NEQ 0 (
  echo.
  echo FAILED. See errors above.
  pause
  exit /b 1
)

echo.
echo DONE: "%SAVEROOT%\save_index.json"
echo Now load it in the web tool: 1) Fast Mode > Load save_index.json
echo.
pause
