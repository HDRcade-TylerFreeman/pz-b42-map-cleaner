\
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HDRcade PZ B42 Map Cleaner - Save Index Helper

Builds a 'save_index.json' for fast loading in the web tool.
- Scans: <SAVE_ROOT>/map/<binX>/<binY>.bin
- Optionally extracts safehouses from sqlite .db files (best effort)

Output schema (schemaVersion=1):
{
  "schemaVersion": 1,
  "createdUtc": "2026-01-21T00:00:00Z",
  "source": { "saveRoot": "...", "tool": "HDRcade Save Index Helper", "toolVersion": "1.0" },
  "world": { "minBx": 0, "maxBx": 0, "minBy": 0, "maxBy": 0, "totalBins": 0 },
  "bins": { "0": [0,1,2], "1": [5,9] },
  "safehouses": [ { "x": 0, "y": 0, "w": 300, "h": 300, "owner": "Bob" } ],
  "warnings": [ "..." ]
}

Note: This helper is intentionally conservative. If safehouses can't be read,
the web tool still works (you just won't get safehouse overlays/protection).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone

try:
    import sqlite3
except Exception:
    sqlite3 = None  # type: ignore


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def is_int_string(s: str) -> bool:
    try:
        int(s)
        return True
    except Exception:
        return False


def scan_bins(save_root: str) -> tuple[dict[str, list[int]], dict[str, int], list[str]]:
    warnings: list[str] = []
    map_dir = os.path.join(save_root, "map")
    if not os.path.isdir(map_dir):
        raise FileNotFoundError(f"Missing map/ directory: {map_dir}")

    t0 = time.time()
    bins: dict[str, list[int]] = defaultdict(list)

    min_bx = 10**18
    min_by = 10**18
    max_bx = -10**18
    max_by = -10**18
    total_bins = 0
    total_folders = 0

    # Use scandir for speed on huge directories
    with os.scandir(map_dir) as it:
        for entry in it:
            if not entry.is_dir():
                continue
            bx_name = entry.name
            if not is_int_string(bx_name):
                continue
            bx = int(bx_name)
            total_folders += 1

            try:
                with os.scandir(entry.path) as it2:
                    for f in it2:
                        if not f.is_file():
                            continue
                        name = f.name
                        if not name.lower().endswith(".bin"):
                            continue
                        base = name[:-4]
                        if not is_int_string(base):
                            continue
                        by = int(base)
                        bins[bx_name].append(by)
                        total_bins += 1
                        if bx < min_bx:
                            min_bx = bx
                        if bx > max_bx:
                            max_bx = bx
                        if by < min_by:
                            min_by = by
                        if by > max_by:
                            max_by = by
            except PermissionError as e:
                warnings.append(f"Permission error scanning folder: {entry.path} ({e})")

    for bx_name, arr in bins.items():
        arr.sort()

    if total_bins == 0:
        warnings.append("No .bin files found under map/. Is this the correct SAVE ROOT?")

    world = {
        "minBx": int(min_bx) if total_bins else 0,
        "maxBx": int(max_bx) if total_bins else 0,
        "minBy": int(min_by) if total_bins else 0,
        "maxBy": int(max_by) if total_bins else 0,
        "totalBins": int(total_bins),
        "totalFolders": int(total_folders),
        "scanSeconds": round(time.time() - t0, 3),
    }
    return dict(bins), world, warnings


def _detect_safehouse_tables(conn) -> list[str]:
    tables: list[str] = []
    cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
    for (name,) in cur.fetchall():
        if isinstance(name, str) and "safehouse" in name.lower():
            tables.append(name)
    return tables


def _table_columns(conn, table: str) -> list[str]:
    cols: list[str] = []
    cur = conn.execute(f"PRAGMA table_info({table!r})")
    for row in cur.fetchall():
        cols.append(str(row[1]))
    return cols


def _pick_owner_column(cols: list[str]) -> str | None:
    preferred = ["owner", "username", "user", "player", "name"]
    lmap = {c.lower(): c for c in cols}
    for p in preferred:
        if p in lmap:
            return lmap[p]
    return None


def _pick_rect_columns(cols: list[str]) -> tuple[str, str, str, str] | None:
    lmap = {c.lower(): c for c in cols}

    def has(*names: str) -> bool:
        return all(n in lmap for n in names)

    if has("x", "y", "w", "h"):
        return (lmap["x"], lmap["y"], lmap["w"], lmap["h"])
    if has("x", "y", "width", "height"):
        return (lmap["x"], lmap["y"], lmap["width"], lmap["height"])
    if has("x1", "y1", "x2", "y2"):
        return (lmap["x1"], lmap["y1"], lmap["x2"], lmap["y2"])
    if has("x", "y", "x2", "y2"):
        return (lmap["x"], lmap["y"], lmap["x2"], lmap["y2"])

    # best-effort variants
    variants = [
        ("x", "y", "xend", "yend"),
        ("x0", "y0", "x1", "y1"),
        ("posx", "posy", "width", "height"),
    ]
    for a, b, c, d in variants:
        if has(a, b, c, d):
            return (lmap[a], lmap[b], lmap[c], lmap[d])

    return None


def _rows_to_safehouses(rows: list[tuple], sel_cols: list[str], rect_cols: tuple[str, str, str, str], owner_col: str | None) -> list[dict]:
    idx = {c: i for i, c in enumerate(sel_cols)}
    rx, ry, r3, r4 = rect_cols
    out: list[dict] = []

    # if end coords style, convert to w/h
    end_style = (r3.lower() in {"x2", "xend", "x1"} or r3.lower().endswith("2")) and (r4.lower() in {"y2", "yend", "y1"} or r4.lower().endswith("2"))

    for row in rows:
        try:
            x = int(row[idx[rx]])
            y = int(row[idx[ry]])
            a = int(row[idx[r3]])
            b = int(row[idx[r4]])

            if end_style or (rx.lower(), ry.lower(), r3.lower(), r4.lower()) in {("x1", "y1", "x2", "y2"), ("x0", "y0", "x1", "y1")}:
                w = max(0, a - x)
                h = max(0, b - y)
            else:
                w = max(0, a)
                h = max(0, b)

            owner = None
            if owner_col and owner_col in idx:
                val = row[idx[owner_col]]
                if val is not None:
                    owner = str(val)

            out.append({"x": x, "y": y, "w": w, "h": h, "owner": owner})
        except Exception:
            continue
    return out


def try_extract_safehouses(save_root: str) -> tuple[list[dict], list[str]]:
    warnings: list[str] = []
    safehouses: list[dict] = []

    if sqlite3 is None:
        warnings.append("sqlite3 unavailable; cannot read safehouses from .db files.")
        return safehouses, warnings

    candidates: list[str] = []
    for name in ["players.db", "safehouses.db", "server.db"]:
        p = os.path.join(save_root, name)
        if os.path.isfile(p):
            candidates.append(p)

    # any other *.db in root
    try:
        for entry in os.scandir(save_root):
            if entry.is_file() and entry.name.lower().endswith(".db") and entry.path not in candidates:
                candidates.append(entry.path)
    except Exception:
        pass

    if not candidates:
        warnings.append("No .db files found in save root (safehouse overlay disabled).")
        return safehouses, warnings

    for db_path in candidates:
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        except Exception as e:
            warnings.append(f"Could not open db (read-only): {os.path.basename(db_path)} ({e})")
            continue

        try:
            tables = _detect_safehouse_tables(conn)
            if not tables:
                continue

            for table in tables:
                try:
                    cols = _table_columns(conn, table)
                    rect_cols = _pick_rect_columns(cols)
                    if not rect_cols:
                        continue
                    owner_col = _pick_owner_column(cols)

                    sel_cols = list(rect_cols)
                    if owner_col:
                        sel_cols.append(owner_col)

                    col_sql = ", ".join([f'"{c}"' for c in sel_cols])
                    q = f'SELECT {col_sql} FROM "{table}"'
                    rows = conn.execute(q).fetchall()
                    safehouses.extend(_rows_to_safehouses(rows, sel_cols, rect_cols, owner_col))
                except Exception:
                    continue
        finally:
            try:
                conn.close()
            except Exception:
                pass

    # de-dup
    seen = set()
    unique = []
    for sh in safehouses:
        key = (sh.get("x"), sh.get("y"), sh.get("w"), sh.get("h"), sh.get("owner"))
        if key in seen:
            continue
        seen.add(key)
        unique.append(sh)

    if not unique:
        warnings.append("Safehouse tables not found or unreadable (safehouse overlay disabled).")
    return unique, warnings


def main() -> int:
    ap = argparse.ArgumentParser(description="Build save_index.json for HDRcade PZ B42 Map Cleaner")
    ap.add_argument("--save-root", required=True, help="Path to SAVE ROOT (must contain map/ folder)")
    ap.add_argument("--out", default="save_index.json", help="Output JSON path (default: save_index.json)")
    ap.add_argument("--pretty", action="store_true", help="Pretty-print JSON (bigger file, easier to read)")
    ap.add_argument("--no-safehouses", action="store_true", help="Skip safehouse extraction from .db files")
    args = ap.parse_args()

    save_root = os.path.abspath(args.save_root)
    out_path = os.path.abspath(args.out)

    if not os.path.isdir(save_root):
        print(f"ERROR: Save root does not exist: {save_root}", file=sys.stderr)
        return 2
    if not os.path.isdir(os.path.join(save_root, "map")):
        print("ERROR: Save root must contain map/ folder.", file=sys.stderr)
        print(f"Given: {save_root}", file=sys.stderr)
        return 2

    print("HDRcade Save Index Helper")
    print("------------------------")
    print("Save root:", save_root)

    bins, world, warnings = scan_bins(save_root)

    safehouses: list[dict] = []
    if not args.no_safehouses:
        sh, sh_warn = try_extract_safehouses(save_root)
        safehouses = sh
        warnings.extend(sh_warn)

    payload = {
        "schemaVersion": 1,
        "createdUtc": utc_now_iso(),
        "source": {
            "saveRoot": save_root,
            "tool": "HDRcade Save Index Helper",
            "toolVersion": "1.0",
        },
        "world": world,
        "bins": bins,
        "safehouses": safehouses,
        "warnings": warnings,
    }

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    if args.pretty:
        text = json.dumps(payload, indent=2, ensure_ascii=False)
    else:
        text = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)

    print(f"OK: wrote {out_path}")
    print(f"bins={world['totalBins']} safehouses={len(safehouses)} warnings={len(warnings)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
