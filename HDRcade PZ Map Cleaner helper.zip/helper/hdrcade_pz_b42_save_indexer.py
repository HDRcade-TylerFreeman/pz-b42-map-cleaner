#!/usr/bin/env python3
"""
HDRcade PZ B42 Map Cleaner — Python Helper
Generates a "Save Index" JSON to load instantly in the web tool (no browser scanning).

Works with: Project Zomboid Build 42.13+ save folders.

Usage:
  python hdrcade_pz_b42_save_indexer.py --save-root "C:\Users\You\Zomboid\Saves\Multiplayer\servertest" --out save_index.json

Notes:
  - This script never deletes anything. It only reads files and writes the index json.
  - Safehouse parsing is best-effort: we try to locate safehouse data in players.db (SQLite) by introspection.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import sqlite3
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

TOOL_NAME = "HDRcade PZ B42 Map Cleaner — Helper"
TOOL_VERSION = "1.0.0"
SCHEMA_VERSION = 1

BIN_DIR_RE = re.compile(r"^\d+$")
BIN_FILE_RE = re.compile(r"^(\d+)\.bin$", re.IGNORECASE)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def eprint(*a: Any) -> None:
    print(*a, file=sys.stderr)


def is_int_str(s: str) -> bool:
    return bool(BIN_DIR_RE.match(s.strip()))


def human(n: int) -> str:
    return f"{n:,}"


def find_map_dir(save_root: Path) -> Path:
    """Return the map/ directory under the save root (or raise)."""
    direct = save_root / "map"
    if direct.is_dir():
        return direct

    # Some users accidentally select the parent folder (e.g., .../Multiplayer)
    # Try one level down where map/ exists.
    for child in save_root.iterdir():
        if not child.is_dir():
            continue
        cand = child / "map"
        if cand.is_dir():
            return cand

    raise FileNotFoundError(f"Couldn't find a 'map' folder under: {save_root}")


@dataclass
class ScanResult:
    bins: Dict[str, List[int]]
    total: int
    min_bx: int
    max_bx: int
    min_by: int
    max_by: int
    folder_count: int


def scan_map_bins(map_dir: Path, progress: bool = True) -> ScanResult:
    """
    Scan coordinate .bin files in:
      map/<bx>/<by>.bin

    Returns bins as:
      {"1250":[0,1,2,...], "1251":[...], ...}
    """
    bins: Dict[str, List[int]] = {}
    total = 0
    min_bx = 2**31 - 1
    max_bx = -2**31
    min_by = 2**31 - 1
    max_by = -2**31
    folder_count = 0

    # os.scandir is significantly faster than Path.rglob for huge folders.
    with os.scandir(map_dir) as it:
        for entry in it:
            if not entry.is_dir():
                continue
            name = entry.name
            if not is_int_str(name):
                continue
            bx = int(name)
            folder_count += 1
            bx_key = str(bx)
            arr = bins.get(bx_key)
            if arr is None:
                arr = []
                bins[bx_key] = arr

            min_bx = min(min_bx, bx)
            max_bx = max(max_bx, bx)

            # Scan files in this bx folder
            try:
                with os.scandir(entry.path) as sub:
                    for fe in sub:
                        if not fe.is_file():
                            continue
                        m = BIN_FILE_RE.match(fe.name)
                        if not m:
                            continue
                        by = int(m.group(1))
                        arr.append(by)
                        total += 1
                        min_by = min(min_by, by)
                        max_by = max(max_by, by)
            except PermissionError:
                # Skip unreadable dirs
                continue

            if progress and folder_count % 75 == 0:
                eprint(f"[scan] folders={human(folder_count)} bins={human(total)} ...")

    # Sort for stable output (helps diffs + compressibility)
    for arr in bins.values():
        arr.sort()

    if total == 0:
        # Avoid bogus infinities
        min_bx = max_bx = min_by = max_by = 0

    return ScanResult(
        bins=bins,
        total=total,
        min_bx=min_bx,
        max_bx=max_bx,
        min_by=min_by,
        max_by=max_by,
        folder_count=folder_count,
    )


# --------------------------
# Safehouse parsing (best-effort)
# --------------------------

def list_sqlite_tables(conn: sqlite3.Connection) -> List[str]:
    cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    return [r[0] for r in cur.fetchall()]


def table_columns(conn: sqlite3.Connection, table: str) -> List[str]:
    cur = conn.execute(f"PRAGMA table_info('{table}')")
    return [r[1] for r in cur.fetchall()]  # column name at index 1


def pick_col(cols: List[str], names: Iterable[str]) -> Optional[str]:
    lower = {c.lower(): c for c in cols}
    for n in names:
        if n.lower() in lower:
            return lower[n.lower()]
    return None


def guess_safehouse_tables(conn: sqlite3.Connection) -> List[Tuple[str, List[str]]]:
    """Return candidate tables that likely contain safehouse rectangles."""
    candidates: List[Tuple[str, List[str]]] = []
    for t in list_sqlite_tables(conn):
        cols = table_columns(conn, t)
        lcols = [c.lower() for c in cols]
        t_low = t.lower()
        if "safehouse" in t_low or "safe_house" in t_low:
            candidates.append((t, cols))
            continue

        # Heuristic: table has coordinate-ish columns + an owner field
        has_xy = ("x" in lcols and "y" in lcols) or ("x1" in lcols and "y1" in lcols)
        has_owner = any(c in lcols for c in ["owner", "username", "player", "playername"])
        has_size = any(c in lcols for c in ["w", "h", "width", "height", "x2", "y2"])
        if has_xy and has_owner and has_size:
            candidates.append((t, cols))
    return candidates


def extract_safehouses_from_table(conn: sqlite3.Connection, table: str, cols: List[str]) -> List[Dict[str, Any]]:
    """Extract safehouses as [{x,y,w,h,owner,...}] from a sqlite table using heuristics."""
    # Common patterns:
    # 1) x,y,w,h
    # 2) x1,y1,x2,y2
    x = pick_col(cols, ["x", "x1", "x0", "xpos", "posx", "x1pos"])
    y = pick_col(cols, ["y", "y1", "y0", "ypos", "posy", "y1pos"])
    w = pick_col(cols, ["w", "width"])
    h = pick_col(cols, ["h", "height"])
    x2 = pick_col(cols, ["x2", "xmax", "x_end", "x1max"])
    y2 = pick_col(cols, ["y2", "ymax", "y_end", "y1max"])

    owner = pick_col(cols, ["owner", "username", "player", "playername", "steamname", "steam_name"])
    name = pick_col(cols, ["name", "title", "safehousename", "safehouse_name"])
    members = pick_col(cols, ["members", "players", "whitelist", "allowed", "allowedplayers", "allowed_players"])

    # Can't do much without some coordinate basis
    if not (x and y):
        return []

    select_cols = [c for c in [x, y, w, h, x2, y2, owner, name, members] if c]
    sel = ", ".join([f'"{c}"' for c in select_cols])
    q = f'SELECT {sel} FROM "{table}"'

    out: List[Dict[str, Any]] = []
    try:
        cur = conn.execute(q)
        rows = cur.fetchall()
    except Exception:
        return out

    idx = {col: i for i, col in enumerate(select_cols)}

    for r in rows:
        try:
            x_val = r[idx[x]]
            y_val = r[idx[y]]
            if x_val is None or y_val is None:
                continue
            x_i = int(x_val)
            y_i = int(y_val)

            # Determine w/h
            w_i: Optional[int] = None
            h_i: Optional[int] = None
            if w and h and r[idx[w]] is not None and r[idx[h]] is not None:
                w_i = int(r[idx[w]])
                h_i = int(r[idx[h]])
            elif x2 and y2 and r[idx[x2]] is not None and r[idx[y2]] is not None:
                w_i = int(r[idx[x2]]) - x_i
                h_i = int(r[idx[y2]]) - y_i
            else:
                continue

            if w_i <= 0 or h_i <= 0:
                continue

            rec: Dict[str, Any] = {"x": x_i, "y": y_i, "w": w_i, "h": h_i}
            if owner and r[idx[owner]] is not None:
                rec["owner"] = str(r[idx[owner]])
            else:
                rec["owner"] = "Unknown"

            if name and r[idx[name]] is not None:
                rec["name"] = str(r[idx[name]])

            if members and r[idx[members]] is not None:
                # Might be CSV / JSON / blob-like text. Keep as string.
                rec["membersRaw"] = str(r[idx[members]])

            rec["source"] = f"{table}"
            out.append(rec)
        except Exception:
            continue

    return out


def extract_safehouses(save_root: Path) -> Tuple[List[Dict[str, Any]], List[str]]:
    """Try to extract safehouses from common DB files in the save root."""
    warnings: List[str] = []
    safehouses: List[Dict[str, Any]] = []

    db_candidates: List[Path] = []
    for n in ["players.db", "Players.db", "players.sqlite", "world.db", "World.db"]:
        p = save_root / n
        if p.is_file():
            db_candidates.append(p)

    # Add any other .db in the root as fallback
    for p in save_root.glob("*.db"):
        if p not in db_candidates:
            db_candidates.append(p)

    if not db_candidates:
        warnings.append("No .db files found in save root; safehouses not extracted.")
        return safehouses, warnings

    for db_path in db_candidates:
        try:
            conn = sqlite3.connect(str(db_path))
        except Exception as e:
            warnings.append(f"Failed to open sqlite DB {db_path.name}: {e}")
            continue

        try:
            candidates = guess_safehouse_tables(conn)
            if not candidates:
                continue

            for table, cols in candidates:
                rows = extract_safehouses_from_table(conn, table, cols)
                if rows:
                    for r in rows:
                        r["sourceDb"] = db_path.name
                    safehouses.extend(rows)
        finally:
            try:
                conn.close()
            except Exception:
                pass

    # De-dupe safehouses
    seen = set()
    deduped = []
    for sh in safehouses:
        key = (sh.get("x"), sh.get("y"), sh.get("w"), sh.get("h"), sh.get("owner"), sh.get("name"))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(sh)
    safehouses = deduped

    if not safehouses:
        warnings.append("Safehouse extraction found no safehouses (schema/version may differ).")

    return safehouses, warnings


# --------------------------
# Main
# --------------------------

def build_index(save_root: Path, out_path: Path, no_safehouses: bool, quiet: bool) -> Dict[str, Any]:
    save_root = save_root.expanduser().resolve()
    if not save_root.exists():
        raise FileNotFoundError(f"Save root does not exist: {save_root}")

    map_dir = find_map_dir(save_root)

    if not quiet:
        eprint(f"[info] save_root: {save_root}")
        eprint(f"[info] map_dir:   {map_dir}")
        eprint(f"[info] scanning .bin files ...")

    scan = scan_map_bins(map_dir, progress=(not quiet))

    warnings: List[str] = []
    if scan.total >= 250_000:
        warnings.append("Large server detected: index strongly recommended (you're generating it now).")
    if scan.total == 0:
        warnings.append("No .bin files found under map/. Are you pointing at the correct save folder?")

    safehouses: List[Dict[str, Any]] = []
    if not no_safehouses:
        if not quiet:
            eprint("[info] extracting safehouses (best-effort) ...")
        sh, sh_warn = extract_safehouses(save_root)
        safehouses = sh
        warnings.extend(sh_warn)

    world = {
        "saveRoot": str(save_root),
        "mapDir": str(map_dir),
        "totalBins": scan.total,
        "minBx": scan.min_bx,
        "maxBx": scan.max_bx,
        "minBy": scan.min_by,
        "maxBy": scan.max_by,
        "folders": scan.folder_count,
    }

    payload: Dict[str, Any] = {
        "schemaVersion": SCHEMA_VERSION,
        "createdUtc": utc_now_iso(),
        "tool": {
            "name": TOOL_NAME,
            "version": TOOL_VERSION,
            "python": sys.version.split()[0],
            "platform": platform.platform(),
        },
        "world": world,
        "bins": scan.bins,
        "safehouses": safehouses,
        "warnings": warnings,
    }

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, indent=2, sort_keys=False), encoding="utf-8")

    if not quiet:
        eprint(f"[done] bins={human(scan.total)} folders={human(scan.folder_count)} safehouses={human(len(safehouses))}")
        eprint(f"[done] wrote: {out_path}")

    return payload


def interactive_path(prompt: str) -> Path:
    while True:
        p = input(prompt).strip().strip('"')
        if not p:
            continue
        pp = Path(p)
        if pp.exists():
            return pp
        print("Path not found. Try again.")


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Generate HDRcade PZ B42 Map Cleaner Save Index JSON")
    ap.add_argument("--save-root", dest="save_root", type=str, default=None,
                    help="Path to the save root (contains map/ and usually players.db)")
    ap.add_argument("--out", dest="out", type=str, default="save_index.json",
                    help="Output JSON path (default: save_index.json in current directory)")
    ap.add_argument("--no-safehouses", action="store_true", help="Skip safehouse extraction (faster).")
    ap.add_argument("--quiet", action="store_true", help="Less console output.")
    args = ap.parse_args(argv)

    if args.save_root is None:
        print("HDRcade Save Index Helper")
        print("Paste your SAVE ROOT path (the folder that contains map/).")
        save_root = interactive_path("Save root path: ")
    else:
        save_root = Path(args.save_root)

    out_path = Path(args.out)

    try:
        build_index(save_root, out_path, args.no_safehouses, args.quiet)
        return 0
    except Exception as e:
        eprint("[error]", e)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
